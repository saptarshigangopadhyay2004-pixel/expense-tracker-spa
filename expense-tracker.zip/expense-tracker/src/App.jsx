import { useMemo, useState } from 'react';
import useLocalStorage from './hooks/useLocalStorage';
import Header from './components/Header';
import Summary from './components/Summary';
import ExpenseForm from './components/ExpenseForm';
import Filters from './components/Filters';
import TransactionList from './components/TransactionList';
import CategoryPieChart from './components/charts/CategoryPieChart';
import IncomeExpenseBarChart from './components/charts/IncomeExpenseBarChart';
import DailyTrendLineChart from './components/charts/DailyTrendLineChart';
import { currentMonth, monthKey } from './utils/helpers';

const defaultFilters = () => ({ month: currentMonth(), type: 'All', category: 'All', search: '' });

export default function App() {
  const [transactions, setTransactions] = useLocalStorage('expense-tracker:transactions', []);
  const [filters, setFilters] = useState(defaultFilters);

  const addTransaction = (t) => setTransactions((prev) => [t, ...prev]);
  const deleteTransaction = (id) => setTransactions((prev) => prev.filter((t) => t.id !== id));

  // Months available in the dropdown (always includes the current month)
  const months = useMemo(() => {
    const set = new Set(transactions.map((t) => monthKey(t.date)));
    set.add(currentMonth());
    return [...set].sort().reverse();
  }, [transactions]);

  // Data for the selected month -> used by summary + charts
  const monthData = useMemo(
    () => transactions.filter((t) => filters.month === 'All' || monthKey(t.date) === filters.month),
    [transactions, filters.month]
  );

  // Fully filtered data -> used by the list + CSV export
  const visible = useMemo(() => {
    const q = filters.search.trim().toLowerCase();
    return monthData
      .filter((t) => filters.type === 'All' || t.type === filters.type)
      .filter((t) => filters.category === 'All' || t.category === filters.category)
      .filter((t) => !q || t.title.toLowerCase().includes(q) || (t.note || '').toLowerCase().includes(q))
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [monthData, filters]);

  return (
    <div className="container">
      <Header />

      <Summary transactions={monthData} month={filters.month} />

      <main className="layout">
        <aside className="col">
          <ExpenseForm onAdd={addTransaction} />
          <Filters
            filters={filters}
            onChange={setFilters}
            months={months}
            onReset={() => setFilters(defaultFilters())}
          />
        </aside>

        <div className="col">
          <TransactionList transactions={visible} onDelete={deleteTransaction} />
        </div>
      </main>

      <section className="charts">
        <CategoryPieChart transactions={monthData} />
        <IncomeExpenseBarChart transactions={transactions} />
        <DailyTrendLineChart transactions={monthData} month={filters.month} />
      </section>

      <footer className="footer">Data is stored locally in your browser (localStorage).</footer>
    </div>
  );
}
