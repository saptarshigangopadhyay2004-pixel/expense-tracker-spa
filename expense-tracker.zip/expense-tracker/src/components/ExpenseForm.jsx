import { useState } from 'react';
import { CATEGORIES, makeId, todayStr } from '../utils/helpers';

const initialForm = () => ({
  type: 'expense',
  title: '',
  amount: '',
  category: CATEGORIES.expense[0],
  date: todayStr(),
  note: '',
});

export default function ExpenseForm({ onAdd }) {
  const [form, setForm] = useState(initialForm);
  const [errors, setErrors] = useState({});

  // One handler for every controlled input
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => {
      const next = { ...prev, [name]: value };
      // when switching type, reset category to the first valid one
      if (name === 'type') next.category = CATEGORIES[value][0];
      return next;
    });
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const validate = () => {
    const errs = {};
    if (!form.title.trim()) errs.title = 'Title is required';
    if (form.amount === '' || Number(form.amount) <= 0) errs.amount = 'Enter an amount greater than 0';
    if (!form.date) errs.date = 'Date is required';
    return errs;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    onAdd({
      id: makeId(),
      type: form.type,
      title: form.title.trim(),
      amount: Number(form.amount),
      category: form.category,
      date: form.date,
      note: form.note.trim(),
    });

    // keep type/category/date for quick repeat entry; clear the rest
    setForm((prev) => ({ ...prev, title: '', amount: '', note: '' }));
  };

  return (
    <section className="card">
      <h2>Add Transaction</h2>
      <form onSubmit={handleSubmit} noValidate className="form">
        <div className="toggle">
          <label className={form.type === 'expense' ? 'active expense' : ''}>
            <input
              type="radio"
              name="type"
              value="expense"
              checked={form.type === 'expense'}
              onChange={handleChange}
            />
            Expense
          </label>
          <label className={form.type === 'income' ? 'active income' : ''}>
            <input
              type="radio"
              name="type"
              value="income"
              checked={form.type === 'income'}
              onChange={handleChange}
            />
            Income
          </label>
        </div>

        <div className="field">
          <label htmlFor="title">Title</label>
          <input
            id="title"
            name="title"
            type="text"
            placeholder="e.g. Lunch, Salary"
            value={form.title}
            onChange={handleChange}
          />
          {errors.title && <small className="error">{errors.title}</small>}
        </div>

        <div className="row">
          <div className="field">
            <label htmlFor="amount">Amount (₹)</label>
            <input
              id="amount"
              name="amount"
              type="number"
              min="0"
              step="0.01"
              placeholder="0.00"
              value={form.amount}
              onChange={handleChange}
            />
            {errors.amount && <small className="error">{errors.amount}</small>}
          </div>

          <div className="field">
            <label htmlFor="date">Date</label>
            <input id="date" name="date" type="date" value={form.date} onChange={handleChange} />
            {errors.date && <small className="error">{errors.date}</small>}
          </div>
        </div>

        <div className="field">
          <label htmlFor="category">Category</label>
          <select id="category" name="category" value={form.category} onChange={handleChange}>
            {CATEGORIES[form.type].map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        <div className="field">
          <label htmlFor="note">Note (optional)</label>
          <input
            id="note"
            name="note"
            type="text"
            placeholder="Any details"
            value={form.note}
            onChange={handleChange}
          />
        </div>

        <button type="submit" className="btn btn-primary">
          + Add {form.type === 'expense' ? 'Expense' : 'Income'}
        </button>
      </form>
    </section>
  );
}
