import { exportToCSV } from '../utils/helpers';

export default function ExportButton({ transactions }) {
  const handleExport = () => exportToCSV(transactions, 'expense-tracker.csv');

  return (
    <button
      type="button"
      className="btn btn-outline"
      onClick={handleExport}
      disabled={transactions.length === 0}
    >
      ⬇ Export CSV
    </button>
  );
}
