import { formatCurrency, monthLabel, sumBy } from '../utils/helpers';

export default function Summary({ transactions, month }) {
  const income = sumBy(transactions, 'income');
  const expense = sumBy(transactions, 'expense');
  const balance = income - expense;

  return (
    <section className="card">
      <h2>Monthly Summary — {monthLabel(month)}</h2>
      <div className="summary-grid">
        <div className="stat stat-income">
          <span>Total Income</span>
          <strong>{formatCurrency(income)}</strong>
        </div>
        <div className="stat stat-expense">
          <span>Total Expenses</span>
          <strong>{formatCurrency(expense)}</strong>
        </div>
        <div className={`stat ${balance >= 0 ? 'stat-balance' : 'stat-negative'}`}>
          <span>Balance</span>
          <strong>{formatCurrency(balance)}</strong>
        </div>
        <div className="stat">
          <span>Transactions</span>
          <strong>{transactions.length}</strong>
        </div>
      </div>
    </section>
  );
}
