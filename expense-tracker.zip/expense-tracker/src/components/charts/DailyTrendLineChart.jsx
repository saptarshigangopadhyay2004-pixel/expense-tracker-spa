import { useMemo } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';
import { currentMonth, formatCurrency, monthLabel } from '../../utils/helpers';

export default function DailyTrendLineChart({ transactions, month }) {
  const data = useMemo(() => {
    const perDay = {};
    transactions
      .filter((t) => t.type === 'expense')
      .forEach((t) => {
        perDay[t.date] = (perDay[t.date] || 0) + t.amount;
      });

    // A specific month: show every day (so gaps appear as 0)
    if (month !== 'All') {
      const [y, m] = month.split('-').map(Number);
      const daysInMonth = new Date(y, m, 0).getDate();
      const lastDay = month === currentMonth() ? new Date().getDate() : daysInMonth;
      return Array.from({ length: lastDay }, (_, i) => {
        const day = String(i + 1).padStart(2, '0');
        return { day: String(i + 1), Spent: perDay[`${month}-${day}`] || 0 };
      });
    }

    // All time: only days that have expenses
    return Object.keys(perDay)
      .sort()
      .map((date) => ({ day: date.slice(5), Spent: perDay[date] }));
  }, [transactions, month]);

  const hasData = data.some((d) => d.Spent > 0);

  return (
    <section className="card card-wide">
      <h2>Daily Expense Trend — {monthLabel(month)}</h2>
      {!hasData ? (
        <p className="empty">No expense data for this period.</p>
      ) : (
        <div className="chart-box">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ top: 10, right: 15, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="day" stroke="var(--muted)" fontSize={12} />
              <YAxis stroke="var(--muted)" fontSize={12} width={55} />
              <Tooltip
                formatter={(v) => formatCurrency(v)}
                labelFormatter={(l) => (month === 'All' ? `Date: ${l}` : `Day ${l}`)}
                contentStyle={tooltipStyle}
              />
              <Line type="monotone" dataKey="Spent" stroke="#6366f1" strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </section>
  );
}

const tooltipStyle = {
  background: 'var(--surface)',
  border: '1px solid var(--border)',
  borderRadius: 8,
  color: 'var(--text)',
};
