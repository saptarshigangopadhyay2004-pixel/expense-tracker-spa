import { useMemo } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from 'recharts';
import { formatCurrency, monthKey, monthLabel } from '../../utils/helpers';

// Compares income vs expense for each of the last 6 months that have data
export default function IncomeExpenseBarChart({ transactions }) {
  const data = useMemo(() => {
    const byMonth = {};
    transactions.forEach((t) => {
      const key = monthKey(t.date);
      byMonth[key] = byMonth[key] || { income: 0, expense: 0 };
      byMonth[key][t.type] += t.amount;
    });
    return Object.keys(byMonth)
      .sort()
      .slice(-6)
      .map((key) => ({
        month: monthLabel(key, true),
        Income: byMonth[key].income,
        Expense: byMonth[key].expense,
      }));
  }, [transactions]);

  return (
    <section className="card">
      <h2>Income vs Expense</h2>
      {data.length === 0 ? (
        <p className="empty">Add transactions to see the comparison.</p>
      ) : (
        <div className="chart-box">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" stroke="var(--muted)" fontSize={12} />
              <YAxis stroke="var(--muted)" fontSize={12} width={55} />
              <Tooltip formatter={(v) => formatCurrency(v)} contentStyle={tooltipStyle} cursor={{ fill: 'rgba(128,128,128,0.1)' }} />
              <Legend />
              <Bar dataKey="Income" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Expense" fill="#ef4444" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </section>
  );
}

const tooltipStyle = {
  background: 'var(--surface)',
  border: '1px solid var(--border)',
  borderRadius: 8,
  color: 'var(--text)',
};
