import { ALL_CATEGORIES, monthLabel } from '../utils/helpers';

export default function Filters({ filters, onChange, months, onReset }) {
  const handleChange = (e) => onChange({ ...filters, [e.target.name]: e.target.value });

  return (
    <section className="card">
      <div className="card-head">
        <h2>Filters</h2>
        <button type="button" className="btn btn-ghost" onClick={onReset}>
          Reset
        </button>
      </div>

      <div className="filters">
        <div className="field">
          <label htmlFor="f-month">Month</label>
          <select id="f-month" name="month" value={filters.month} onChange={handleChange}>
            <option value="All">All time</option>
            {months.map((m) => (
              <option key={m} value={m}>
                {monthLabel(m)}
              </option>
            ))}
          </select>
        </div>

        <div className="field">
          <label htmlFor="f-type">Type</label>
          <select id="f-type" name="type" value={filters.type} onChange={handleChange}>
            <option value="All">All</option>
            <option value="expense">Expense</option>
            <option value="income">Income</option>
          </select>
        </div>

        <div className="field">
          <label htmlFor="f-category">Category</label>
          <select id="f-category" name="category" value={filters.category} onChange={handleChange}>
            <option value="All">All categories</option>
            {ALL_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        <div className="field">
          <label htmlFor="f-search">Search</label>
          <input
            id="f-search"
            name="search"
            type="search"
            placeholder="Search title or note…"
            value={filters.search}
            onChange={handleChange}
          />
        </div>
      </div>
    </section>
  );
}
