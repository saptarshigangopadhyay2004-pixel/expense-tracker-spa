import ExportButton from './ExportButton';
import { formatCurrency, formatDate } from '../utils/helpers';

export default function TransactionList({ transactions, onDelete }) {
  return (
    <section className="card">
      <div className="card-head">
        <h2>Transactions ({transactions.length})</h2>
        <ExportButton transactions={transactions} />
      </div>

      {transactions.length === 0 ? (
        <p className="empty">No transactions found. Add one or change the filters.</p>
      ) : (
        <ul className="tx-list">
          {transactions.map((t) => (
            <li key={t.id} className="tx">
              <div className={`tx-icon ${t.type}`}>{t.type === 'income' ? '↑' : '↓'}</div>
              <div className="tx-main">
                <strong>{t.title}</strong>
                <span className="tx-meta">
                  <span className="badge">{t.category}</span> {formatDate(t.date)}
                  {t.note && <> · {t.note}</>}
                </span>
              </div>
              <div className={`tx-amount ${t.type}`}>
                {t.type === 'income' ? '+' : '-'}
                {formatCurrency(t.amount)}
              </div>
              <button
                type="button"
                className="btn-delete"
                aria-label={`Delete ${t.title}`}
                title="Delete"
                onClick={() => onDelete(t.id)}
              >
                ✕
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
