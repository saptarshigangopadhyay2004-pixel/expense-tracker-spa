export default function Header() {
  return (
    <header className="header">
      <h1>💰 Expense Tracker</h1>
      <p>Record, categorize, filter and analyze your income and expenses.</p>
    </header>
  );
}
