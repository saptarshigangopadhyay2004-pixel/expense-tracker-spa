export const CATEGORIES = {
  expense: ['Food', 'Transport', 'Shopping', 'Bills', 'Health', 'Entertainment', 'Education', 'Other'],
  income: ['Salary', 'Freelance', 'Gift', 'Investment', 'Other'],
};

export const ALL_CATEGORIES = [...new Set([...CATEGORIES.expense, ...CATEGORIES.income])];

export const CHART_COLORS = [
  '#6366f1', '#f59e0b', '#10b981', '#ef4444',
  '#06b6d4', '#ec4899', '#8b5cf6', '#84cc16', '#f97316',
];

const pad = (n) => String(n).padStart(2, '0');

export const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};

export const currentMonth = () => todayStr().slice(0, 7);

export const monthKey = (dateStr) => dateStr.slice(0, 7);

export const monthLabel = (key, short = false) => {
  if (key === 'All') return 'All time';
  const [y, m] = key.split('-').map(Number);
  return new Date(y, m - 1, 1).toLocaleString('en-IN', {
    month: short ? 'short' : 'long',
    year: 'numeric',
  });
};

export const formatCurrency = (n) =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(n || 0);

export const formatDate = (dateStr) => {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

export const makeId = () =>
  typeof crypto !== 'undefined' && crypto.randomUUID
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;

export const sumBy = (list, type) =>
  list.filter((t) => t.type === type).reduce((total, t) => total + t.amount, 0);

// ---- CSV export ----
const csvCell = (value) => `"${String(value ?? '').replace(/"/g, '""')}"`;

export function exportToCSV(transactions, filename = 'expenses.csv') {
  const header = ['Date', 'Type', 'Title', 'Category', 'Amount', 'Note'];
  const rows = transactions.map((t) => [t.date, t.type, t.title, t.category, t.amount, t.note]);
  const csv = [header, ...rows].map((row) => row.map(csvCell).join(',')).join('\r\n');

  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
