# 💰 Expense Tracker (React + Vite)

A responsive Expense Tracker SPA built with React, controlled forms and Recharts.

## Features
- Add / delete income and expense transactions (controlled form with validation)
- Monthly summary (income, expenses, balance, count)
- Filter by month, type, category and search text
- Pie chart – expenses by category
- Bar chart – income vs expense (last 6 months)
- Line chart – per-day expense trend
- Export the filtered list to CSV
- Data saved in `localStorage`

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build     # output in /dist
npm run preview
```

## Deploy on Netlify (via GitHub)
1. Push this folder to a GitHub repository.
2. On Netlify: **Add new site → Import an existing project → GitHub** → choose the repo.
3. Build settings (auto-detected from `netlify.toml`):
   - Build command: `npm run build`
   - Publish directory: `dist`
4. Click **Deploy**.

## Structure
```
index.html              <- web page entry (root div + script)
src/
  main.jsx
  App.jsx
  index.css
  hooks/useLocalStorage.js
  utils/helpers.js
  components/
    Header.jsx  Summary.jsx  ExpenseForm.jsx  Filters.jsx
    TransactionList.jsx  ExportButton.jsx
    charts/ CategoryPieChart.jsx  IncomeExpenseBarChart.jsx  DailyTrendLineChart.jsx
```
